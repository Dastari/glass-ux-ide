/** The fields a catalogue entry needs to be grouped into documents. */
export interface FamilyEntry {
    id: string;
    name: string;
    family: string;
}
/** Which exports share a document, from a project's `families` and `familyMembers`. */
export interface FamilyConfig {
    /** Family id to root component. */
    roots: Readonly<Record<string, string>>;
    /** Component id to the related exports on its page, in display order. */
    related: Readonly<Record<string, readonly string[]>>;
}
/** Groups a catalogue into documents, one per root component, with its related exports. */
export declare function createComponentFamilies<T extends FamilyEntry>(catalogue: readonly T[], { roots, related }: FamilyConfig): {
    all: (T & {
        components: T[];
    })[];
    find: (id: string) => (T & {
        components: T[];
    }) | undefined;
    destination: (id: string) => {
        id: string;
        hash?: string;
    };
};
