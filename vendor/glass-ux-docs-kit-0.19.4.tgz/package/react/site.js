"use client";
import { jsx as _jsx } from "react/jsx-runtime";
import { createContext, lazy, use } from "react";
import { createComponentFamilies } from "./families.js";
/** Gallery navigation groups in display order; sections sort by group, then by their `order`. */
export const GROUPS = ["Foundations", "Components", "Patterns", "Charts", "AI", "Screens"];
const moduleId = (path) => path.split("/").pop().replace(/\.[^.]+$/, "");
/** Caches a loader's result per id, so pages sharing an export fetch it once. */
function once(load) {
    const promises = new Map();
    return (id) => {
        let promise = promises.get(id);
        if (!promise) {
            promise = load(id);
            promises.set(id, promise);
        }
        return promise;
    };
}
function createPageContent({ demoLoaders, loadApi, loadExample }, coverage) {
    const demoModules = new Map(Object.entries(demoLoaders).map(([path, loader]) => [moduleId(path), loader]));
    const loadDemo = once((id) => demoModules.get(id)?.() ?? Promise.reject(new Error(`No demo for ${id}.`)));
    return {
        specimens: new Map(coverage.map((entry) => [entry.id, entry.specimens ?? []])),
        loadDemo: (id) => (demoModules.has(id) ? loadDemo(id) : undefined),
        focusedDemos: new Map([...demoModules.keys()].map((id) => [id, lazy(() => loadDemo(id))])),
        loadApi: once(loadApi),
        loadExample: once(loadExample),
    };
}
function createRuntime(site) {
    const sections = Object.entries(site.sectionMetas)
        .flatMap(([path, meta]) => {
        const loader = site.sectionLoaders[path.replace(/\.meta\.js$/, ".section.js").replace(/\.meta\.ts$/, ".section.tsx")];
        return loader ? [{ ...meta, Component: lazy(loader) }] : [];
    })
        .toSorted((a, b) => GROUPS.indexOf(a.group) - GROUPS.indexOf(b.group) || a.order - b.order);
    let content;
    return {
        sections,
        findSection: (id) => sections.find((section) => section.id === id),
        families: createComponentFamilies(site.catalogue, site.families),
        /** Component page content: a stable promise, so a page can suspend on it with `use`. */
        content: () => (content ??= site.loadContent().then(async (loaded) => createPageContent(loaded, await loaded.loadCoverage()))),
    };
}
const runtimes = new WeakMap();
/** One site's sections, families and cached loaders, shared by its pages. */
export function siteRuntime(site) {
    let runtime = runtimes.get(site);
    if (!runtime) {
        runtime = createRuntime(site);
        runtimes.set(site, runtime);
    }
    return runtime;
}
const DocsSiteContext = /* @__PURE__ */ createContext(null);
/** Gives the documentation pages their project's generated `site`. Wrap the routes in it once. */
export function DocsKitProvider({ site, children }) {
    return _jsx(DocsSiteContext, { value: site, children: children });
}
/** The `site` from the nearest {@link DocsKitProvider}. */
export function useDocsSite() {
    const site = use(DocsSiteContext);
    if (!site)
        throw new Error("Documentation pages need a DocsKitProvider.");
    return site;
}
