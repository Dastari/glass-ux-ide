"use client";
import { jsx as _jsx, jsxs as _jsxs, Fragment as _Fragment } from "react/jsx-runtime";
// oxlint-disable jsx-a11y/no-noninteractive-tabindex -- documentation scrollers must be keyboard reachable
import { Suspense, use, useEffect, useMemo, useRef, useState } from "react";
import { DemoScope, HiddenSpecimens, specimenAnchor } from "./demo-scope.js";
import { siteRuntime, useDocsSite } from "./site.js";
import { VerticalTabNav } from "glass-ux/vertical-tabs";
import { Skeleton } from "glass-ux/skeleton";
import { Notice } from "glass-ux/notice";
import { Markdown } from "glass-ux/ai/markdown";
import { Badge } from "glass-ux/badge";
import { useMediaQuery } from "glass-ux/hooks";
import { CodeBlock } from "glass-ux/ai/code-block";
const PHONE_QUERY = "(width < 48rem)";
const collectionOf = (site, id) => site.collections.find((collection) => collection.id === id);
function Props({ props, label, htmlAttributes = false, }) {
    const own = props.filter((prop) => !prop.inherited);
    const inherited = props.filter((prop) => prop.inherited);
    const table = (rows, inherited = false) => (_jsx("div", { className: "gallery-api-scroll", tabIndex: 0, role: "region", "aria-label": `${label}${inherited ? " inherited" : ""} properties`, children: _jsxs("table", { className: "gallery-api-table", children: [_jsx("thead", { children: _jsxs("tr", { children: [_jsx("th", { children: "Prop" }), _jsx("th", { children: "Type" }), _jsx("th", { children: "Valid options" }), _jsx("th", { children: "Default" }), _jsx("th", { children: "Description" })] }) }), _jsx("tbody", { children: rows.map((prop) => (_jsxs("tr", { children: [_jsxs("th", { scope: "row", children: [_jsx("code", { dir: "ltr", children: prop.name }), prop.required ? _jsx("span", { children: " required" }) : null] }), _jsx("td", { children: _jsx("code", { dir: "ltr", children: prop.type }) }), _jsx("td", { children: _jsx("code", { dir: "ltr", children: prop.options
                                        .map((value) => JSON.stringify(value))
                                        .join(" · ") || "See type" }) }), _jsx("td", { children: _jsx("code", { dir: "ltr", children: prop.default ?? "—" }) }), _jsx("td", { children: prop.description })] }, prop.name))) })] }) }));
    return (_jsxs(_Fragment, { children: [table(own), inherited.length ? (_jsxs("details", { children: [_jsxs("summary", { children: ["Inherited properties (", inherited.length, ")"] }), table(inherited, true)] })) : null, htmlAttributes ? (_jsx("p", { children: "Also accepts the element\u2019s standard HTML attributes and React DOM events." })) : null] }));
}
/** The public API reference for a single component, including every compound slot. */
export function ApiReference({ id, headingId = "api-title", headingLevel = 2, title = "API", }) {
    const site = useDocsSite();
    const [api, setApi] = useState();
    const [error, setError] = useState();
    useEffect(() => {
        let active = true;
        setApi(undefined);
        setError(undefined);
        siteRuntime(site)
            .content()
            .then((content) => content.loadApi(id))
            .then((value) => {
            if (active)
                setApi(value);
        })
            .catch((reason) => {
            if (active)
                setError(String(reason));
        });
        return () => {
            active = false;
        };
    }, [site, id]);
    const Heading = headingLevel === 2 ? "h2" : "h3";
    const SlotHeading = headingLevel === 2 ? "h3" : "h4";
    return (_jsxs("section", { className: "gallery-api", children: [_jsx(Heading, { id: headingId, children: title }), error ? (_jsx(Notice, { tone: "danger", children: error })) : !api ? (_jsx("div", { "aria-busy": "true", children: _jsx(Skeleton.Text, { lines: 3 }) })) : (_jsxs(_Fragment, { children: [_jsx(CodeBlock, { code: `import { ${collectionOf(site, api.id)?.sample ?? api.name} } from "${api.entry}"`, language: "tsx", title: "Import", label: `${api.name} API import`, headingLevel: headingLevel === 2 ? 3 : 4, wrap: true, maxLines: 0 }), api.props ? (_jsx(Props, { props: api.props, label: api.name, htmlAttributes: api.htmlAttributes })) : null, api.slots.map((slot) => (_jsxs("section", { children: [_jsxs(SlotHeading, { id: `${headingId}-${slot.name.toLowerCase()}`, children: [api.name, ".", slot.name] }), slot.description ? _jsx("p", { children: slot.description }) : null, _jsx(Props, { props: slot.props, label: `${api.name}.${slot.name}`, htmlAttributes: slot.htmlAttributes })] }, slot.name)))] }))] }));
}
/**
 * For each related export after the base component: the specimens an earlier demo in the
 * document already showed (hidden in its demo), and the titles of its own specimens that are
 * all shown above when nothing new is left.
 */
function sharedSpecimens(ids, demoSpecimens) {
    const shown = new Set();
    const result = new Map();
    ids.forEach((id, index) => {
        const own = demoSpecimens.get(id) ?? [];
        const hidden = new Set(shown);
        const fresh = own.filter((specimen) => !hidden.has(specimen.key));
        result.set(id, { hidden, above: index > 0 && own.length > 0 && fresh.length === 0 ? own : null });
        for (const specimen of own)
            shown.add(specimen.key);
    });
    return result;
}
const EMPTY = new Set();
/** A centered, single-page component document with a section-jump side rail. */
export function ComponentDocumentation({ id }) {
    const site = useDocsSite();
    const runtime = siteRuntime(site);
    const content = use(runtime.content());
    const family = runtime.families.find(id);
    const collection = collectionOf(site, id);
    const component = collection ?? family;
    const components = useMemo(() => family?.components ?? (component ? [component] : []), [family, component]);
    const sharing = useMemo(() => sharedSpecimens(components.map((item) => item.id), content.specimens), [components, content]);
    const documentSections = useMemo(() => [
        { value: "examples", label: "Examples" },
        ...components.slice(1).map((item) => ({
            value: item.id,
            label: item.name,
        })),
        { value: "usage", label: "Usage" },
        { value: "api", label: "API" },
    ], [components]);
    const phone = useMediaQuery(PHONE_QUERY);
    const root = useRef(null);
    const [active, setActive] = useState("examples");
    useEffect(() => {
        let cancelled = false;
        let frame = 0;
        const targets = documentSections
            .map((item) => root.current?.querySelector(`#${item.value}`))
            .filter((target) => !!target);
        const scrollRoot = root.current?.closest("[data-scroll-container]") ?? null;
        const observer = new IntersectionObserver((entries) => {
            const current = entries
                .filter((entry) => entry.isIntersecting)
                .sort((a, b) => a.boundingClientRect.top - b.boundingClientRect.top)[0];
            if (current)
                setActive(current.target.id);
        }, {
            root: scrollRoot,
            rootMargin: `0px 0px -${Math.max(0, (scrollRoot?.clientHeight ?? 100) - 80)}px 0px`,
        });
        targets.forEach((target) => observer.observe(target));
        // Sections above the target keep growing for a moment after the jump. Chromium's scroll
        // anchoring holds the target in place; Safari has none, so the target ends up far below
        // the view. Hold its place until the person scrolls or the layout has been still for a while.
        let release = () => { };
        const holdPlace = (target) => {
            release();
            const edge = scrollRoot ?? document.documentElement;
            const offset = () => target.getBoundingClientRect().top -
                (scrollRoot ? scrollRoot.getBoundingClientRect().top : 0);
            const wanted = offset();
            const observer = new ResizeObserver(() => {
                const moved = offset() - wanted;
                if (Math.abs(moved) > 1)
                    (scrollRoot ?? window).scrollBy({ top: moved });
            });
            if (root.current)
                observer.observe(root.current);
            const events = ["wheel", "touchstart", "keydown", "pointerdown"];
            const stop = () => {
                observer.disconnect();
                window.clearTimeout(timer);
                events.forEach((name) => edge.removeEventListener(name, stop));
                if (release === stop)
                    release = () => { };
            };
            const timer = window.setTimeout(stop, 3000);
            events.forEach((name) => edge.addEventListener(name, stop, { passive: true }));
            release = stop;
        };
        const goToHash = () => {
            release();
            const hash = decodeURIComponent(window.location.hash.slice(1));
            // Old per-export routes still open the same specimen, usage or API within
            // their parent document. Named family anchors also work on a direct load.
            const related = component && id !== component.id;
            const targetId = related
                ? !hash || hash === "examples"
                    ? id
                    : hash === "api" || hash === "usage"
                        ? `${hash}-${id}`
                        : hash
                : hash;
            if (!targetId)
                return;
            // Large families can finish loading examples above a deep link. Scroll only
            // after their modules, source and API content have committed their layout.
            void Promise.allSettled(components.flatMap((item) => [
                content.loadDemo(item.id),
                content.loadApi(item.id),
                content.loadExample(item.id),
            ])).then(() => {
                if (cancelled)
                    return;
                cancelAnimationFrame(frame);
                frame = requestAnimationFrame(() => {
                    frame = requestAnimationFrame(() => {
                        if (cancelled)
                            return;
                        const target = root.current?.querySelector(`#${CSS.escape(targetId)}`);
                        if (!target)
                            return;
                        target.scrollIntoView({ block: "start" });
                        holdPlace(target);
                    });
                });
            });
        };
        goToHash();
        // A link to another hash on this page does not reload it, and the browser's own
        // jump goes to the section anchor rather than an old route's destination.
        window.addEventListener("hashchange", goToHash);
        return () => {
            cancelled = true;
            release();
            cancelAnimationFrame(frame);
            window.removeEventListener("hashchange", goToHash);
            observer.disconnect();
        };
    }, [id, component, components, documentSections, content]);
    if (!component)
        return (_jsx(Notice, { tone: "warning", children: "This component is not in the catalogue." }));
    const Demo = collection
        ? runtime.findSection(collection.section)?.Component
        : content.focusedDemos.get(component.id);
    return (_jsxs("div", { ref: root, className: "gallery-document-layout", children: [_jsx("aside", { className: "gallery-document-rail", children: _jsx(VerticalTabNav, { "aria-label": "On this page", layout: phone ? "tabs" : "rail", items: documentSections, value: active, renderLink: (item, props) => (_jsx("a", { ...props, href: `#${item.value}`, "aria-current": item.value === active ? "location" : undefined, onClick: () => setActive(item.value) })) }) }), _jsxs("article", { className: "gallery-documentation gallery-component-document", "aria-label": `${component.name} documentation`, children: [_jsxs("header", { className: "gallery-document-intro", children: [_jsx(Badge, { children: site.badges[component.family] ?? "Component reference" }), _jsx("h1", { className: "type-display", children: component.name }), _jsx(Markdown, { text: component.description, className: "gallery-document-description type-body text-fg-muted" }), _jsx(CodeBlock, { code: `import { ${collection?.sample ?? component.name} } from "${component.entry}"`, language: "tsx", title: "Import", label: `${component.name} import`, headingLevel: 2, wrap: true, maxLines: 0 })] }), _jsxs("div", { className: "gallery-document-sections", children: [_jsxs("section", { id: "examples", "aria-labelledby": "examples-title", tabIndex: -1, children: [_jsx("h2", { id: "examples-title", children: "Examples" }), _jsx(Suspense, { fallback: _jsx(Skeleton.Text, { lines: 4 }), children: Demo ? (_jsx(Demo, {})) : (_jsx(Notice, { children: "See the API for this component\u2019s typed contract." })) })] }), components.slice(1).map((item) => {
                                const RelatedDemo = content.focusedDemos.get(item.id);
                                const shared = sharing.get(item.id);
                                return (_jsxs("section", { id: item.id, "aria-labelledby": `${item.id}-title`, tabIndex: -1, className: "gallery-related-component", children: [_jsxs("header", { children: [_jsx("h2", { id: `${item.id}-title`, children: item.name }), _jsx(Markdown, { text: item.description, className: "type-body text-fg-muted" })] }), shared?.above ? (_jsxs("p", { className: "type-body text-fg-muted", "data-shown-above": "", children: ["Shown in the examples above:", " ", shared.above.map((specimen, index) => (_jsxs("span", { children: [index ? ", " : null, _jsx("a", { href: `#${specimenAnchor(specimen.key)}`, children: specimen.title })] }, specimen.key))), "."] })) : (_jsx(Suspense, { fallback: _jsx(Skeleton.Text, { lines: 4 }), children: RelatedDemo ? (_jsx(HiddenSpecimens, { value: shared?.hidden ?? EMPTY, children: _jsx(DemoScope, { value: item.name, children: _jsx(RelatedDemo, {}) }) })) : null }))] }, item.id));
                            }), _jsxs("section", { id: "usage", "aria-labelledby": "usage-title", tabIndex: -1, children: [_jsx("h2", { id: "usage-title", children: "Usage" }), _jsx("p", { children: "Complete examples use the same package as the live demos. Replace fictional sample data with your application\u2019s adapters." }), components.map((item) => (_jsx(UsageExample, { section: item.id, title: item.name, headingId: `usage-${item.id}`, headingLevel: 3 }, item.id)))] }), _jsxs("section", { id: "api", "aria-labelledby": "api-title", tabIndex: -1, children: [_jsx("h2", { id: "api-title", children: "API" }), components.length > 1 ? (_jsx("nav", { "aria-label": "Individual APIs", className: "gallery-api-index", children: components.map((item) => (_jsx("a", { href: `#api-${item.id}`, children: item.name }, item.id))) })) : null, components.map((item) => (_jsx(ApiReference, { id: item.id, title: item.name, headingId: `api-${item.id}`, headingLevel: 3 }, item.id)))] })] })] })] }));
}
/** A Foundation's styled title, introduction and examples in one centered article. Icons retain their usage and API sections. */
export function FoundationDocumentation({ id, badge }) {
    const site = useDocsSite();
    const section = siteRuntime(site).findSection(id);
    if (!section || section.group !== "Foundations")
        return (_jsx(Notice, { tone: "warning", children: "This Foundation is not in the catalogue." }));
    if (collectionOf(site, id))
        return _jsx(ComponentDocumentation, { id: id });
    const { Component } = section;
    const kind = badge ?? section.badge ?? "Foundation";
    return (_jsxs("article", { className: "gallery-documentation gallery-foundation-document", "aria-label": `${section.title} ${kind.toLowerCase()}`, children: [_jsxs("header", { className: "gallery-document-intro", children: [_jsx(Badge, { children: kind }), _jsx("h1", { className: "type-display", children: section.title }), _jsx("p", { className: "gallery-document-description type-body text-fg-muted", children: section.summary })] }), _jsx(Suspense, { fallback: _jsx(Skeleton.Text, { lines: 4 }), children: _jsx(Component, {}) })] }));
}
/** The complete source from the documentation's examples, using the package’s public import paths. */
export function UsageExample({ section, title = "Usage", headingId = "usage-title", headingLevel = 2, }) {
    const site = useDocsSite();
    const [code, setCode] = useState("");
    useEffect(() => {
        let active = true;
        setCode("");
        siteRuntime(site)
            .content()
            .then((content) => content.loadExample(section))
            .then((text) => {
            if (active)
                setCode(text);
        });
        return () => {
            active = false;
        };
    }, [site, section]);
    const Heading = headingLevel === 2 ? "h2" : "h3";
    return (_jsxs("section", { className: "gallery-usage-example", children: [_jsx(Heading, { id: headingId, children: title }), code ? (_jsx(CodeBlock, { code: code, language: "tsx", title: "Complete example", label: `${section} complete example`, headingLevel: headingLevel === 2 ? 3 : 4, lineNumbers: true, maxLines: 32 })) : (_jsx(Skeleton.Text, { lines: 3 }))] }));
}
