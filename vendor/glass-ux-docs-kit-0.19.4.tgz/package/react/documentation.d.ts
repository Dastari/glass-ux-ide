/** Rendering options for one export's complete API reference. */
export interface ApiReferenceProps {
    /** Original component catalogue identifier. */
    id: string;
    /** Unique heading anchor when multiple APIs share a document. @defaultValue `"api-title"` */
    headingId?: string;
    /** Heading level within the surrounding article. @defaultValue `2` */
    headingLevel?: 2 | 3;
    /** Heading text; family documents use the individual export's name. @defaultValue `"API"` */
    title?: string;
}
/** The public API reference for a single component, including every compound slot. */
export declare function ApiReference({ id, headingId, headingLevel, title, }: ApiReferenceProps): import("react").JSX.Element;
/** A centered, single-page component document with a section-jump side rail. */
export declare function ComponentDocumentation({ id }: {
    id: string;
}): import("react").JSX.Element;
export interface FoundationDocumentationProps {
    /** Foundation section identifier, such as colour, typography or space. */
    id: string;
    /** The badge over the title, such as "Tool" or "Filter". Default: the section's `badge`, then "Foundation". */
    badge?: string;
}
/** A Foundation's styled title, introduction and examples in one centered article. Icons retain their usage and API sections. */
export declare function FoundationDocumentation({ id, badge }: FoundationDocumentationProps): import("react").JSX.Element;
/** The complete source from the documentation's examples, using the package’s public import paths. */
export declare function UsageExample({ section, title, headingId, headingLevel, }: {
    /** Original component catalogue identifier for the runnable source. */
    section: string;
    /** Visible section heading. @defaultValue `"Usage"` */
    title?: string;
    /** Unique source heading anchor. @defaultValue `"usage-title"` */
    headingId?: string;
    /** Heading level within the surrounding article. @defaultValue `2` */
    headingLevel?: 2 | 3;
}): import("react").JSX.Element;
