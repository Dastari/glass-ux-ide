/** A version-matched human guide from the installed release. */
export declare function LibraryGuide({ id }: {
    id: string;
}): import("react").JSX.Element;
