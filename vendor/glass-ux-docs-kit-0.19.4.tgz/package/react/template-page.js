import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { Suspense } from "react";
import { Badge } from "glass-ux/badge";
import { Skeleton } from "glass-ux/skeleton";
import { UsageExample } from "./documentation.js";
/** A template's page: the live screen in a bounded frame on the canvas, then its source to copy. */
export function TemplateDocumentation({ id, title, summary, screen: Screen, sources = [], fullScreen, badge = "Template" }) {
    return (_jsxs("article", { className: "gallery-documentation gallery-template-document", "aria-label": `${title} template`, children: [_jsxs("header", { className: "gallery-document-intro", children: [_jsx(Badge, { children: badge }), _jsx("h1", { className: "type-display", children: title }), _jsx("p", { className: "gallery-document-description type-body text-fg-muted", children: summary })] }), fullScreen ? _jsx("div", { className: "flex justify-end", children: fullScreen }) : null, _jsx("div", { className: "gallery-template-stage", "data-template": id, children: _jsx(Suspense, { fallback: _jsx(Skeleton.Block, { className: "h-full", radius: "surface" }), children: _jsx(Screen, {}) }) }), sources.map((source) => (_jsx(UsageExample, { section: source.section, title: source.title, headingId: source.headingId }, source.section)))] }));
}
/** A template alone, filling the viewport. */
export function TemplatePreview({ screen: Screen, shell }) {
    const screen = (_jsx(Suspense, { fallback: _jsx(Skeleton.Block, { className: "h-full", radius: "surface" }), children: _jsx(Screen, {}) }));
    return shell ? shell(screen) : screen;
}
