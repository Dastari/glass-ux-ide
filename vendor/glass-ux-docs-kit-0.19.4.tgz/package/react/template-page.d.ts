import { type ComponentType, type ReactNode } from "react";
/** One block of source under a template, from a section the docs catalogue has examples for. */
export interface TemplateSource {
    /** The section whose example holds the source ("template-settings"). */
    section: string;
    /** Its heading: "Source". */
    title: string;
    /** The heading's id, for a link to it. */
    headingId: string;
}
export interface TemplateDocumentationProps {
    /** Marks the frame with `data-template`, for a test or a page's own style. */
    id?: string;
    /** The page's heading. */
    title: string;
    /** One or two sentences under it. */
    summary: string;
    /** The live screen, drawn in a bounded frame on the canvas. Give a lazy component to load it with the page. */
    screen: ComponentType;
    /** Source to copy, in order under the screen. */
    sources?: readonly TemplateSource[];
    /** The host's link to the screen on its own. */
    fullScreen?: ReactNode;
    /** The badge over the title. Default "Template". */
    badge?: string;
}
/** A template's page: the live screen in a bounded frame on the canvas, then its source to copy. */
export declare function TemplateDocumentation({ id, title, summary, screen: Screen, sources, fullScreen, badge }: TemplateDocumentationProps): import("react").JSX.Element;
export interface TemplatePreviewProps {
    /** The live screen. Give a lazy component to load it with the page. */
    screen: ComponentType;
    /** Puts the screen in a frame, such as the application's own shell. Without it the screen fills what it is given. */
    shell?: (screen: ReactNode) => ReactNode;
}
/** A template alone, filling the viewport. */
export declare function TemplatePreview({ screen: Screen, shell }: TemplatePreviewProps): string | number | bigint | boolean | Iterable<ReactNode> | Promise<string | number | bigint | boolean | import("react").ReactPortal | import("react").ReactElement<unknown, string | import("react").JSXElementConstructor<any>> | Iterable<ReactNode> | null | undefined> | import("react").JSX.Element | null | undefined;
