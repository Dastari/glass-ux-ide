"use client";
import { jsx as _jsx, jsxs as _jsxs, Fragment as _Fragment } from "react/jsx-runtime";
/**
 * Building blocks for gallery sections. Every section uses these so the gallery itself
 * follows one layout: a page header, then specimens (a labelled glass panel holding live
 * examples), then the rules and the tokens the component reads.
 */
import { useContext, useEffect, useState } from "react";
import { clsx as cx } from "clsx";
import { DemoScope, HiddenSpecimens, specimenAnchor } from "./demo-scope.js";
import { Button } from "glass-ux/button";
/** The page wrapper every gallery section renders its header and specimens inside. */
export function SectionPage({ children }) {
    return _jsx("div", { className: "gallery-page", children: children });
}
/** A titled gallery panel of live examples, labelled with the demo scope when one is set; `layout` arranges the examples and `backdrop` paints busy content behind them. */
export function Specimen(props) {
    const hidden = useContext(HiddenSpecimens);
    return props.specimenKey && hidden.has(props.specimenKey) ? null : _jsx(SpecimenPanel, { ...props });
}
function SpecimenPanel({ specimenKey, title, description, children, layout = "row", backdrop, wide, className, }) {
    const scope = useContext(DemoScope);
    return (_jsxs("section", { id: specimenKey ? specimenAnchor(specimenKey) : undefined, className: cx("gallery-specimen", className), "aria-label": scope ? `${scope}: ${title}` : title, "data-wide": wide ? "" : undefined, children: [_jsxs("header", { className: "gallery-specimen-header", children: [_jsx("h2", { className: "gallery-specimen-title", children: title }), description ? (_jsx("p", { className: "gallery-specimen-description", children: description })) : null] }), _jsx("div", { className: cx("gallery-specimen-body", backdrop && "over-imagery"), "data-layout": layout, "data-backdrop": backdrop ? "" : undefined, children: _jsx(DemoScope, { value: scope ? `${scope}: ${title}` : title, children: children }) })] }));
}
/**
 * A specimen with no glass: content sits straight on the ambient canvas, the way L2 tabs,
 * the breadcrumb and entity headers sit in the product (R4.6).
 */
export function OnCanvas({ title, description, children, className, specimenKey, }) {
    const scope = useContext(DemoScope);
    const hidden = useContext(HiddenSpecimens);
    if (specimenKey && hidden.has(specimenKey))
        return null;
    return (_jsxs("section", { id: specimenKey ? specimenAnchor(specimenKey) : undefined, className: cx("flex min-w-0 flex-col gap-4 px-5 py-2", className), "aria-label": scope ? `${scope}: ${title}` : title, "data-wide": "", "data-canvas-specimen": "", children: [_jsxs("header", { children: [_jsx("h2", { className: "gallery-specimen-title", children: title }), description ? (_jsx("p", { className: "gallery-specimen-description", children: description })) : null] }), children] }));
}
/**
 * One slot that swaps a skeleton for its content in place, so a test can measure both in the
 * same box (R9.3). Starts on the skeleton.
 */
export function SwapSlot({ id, skeleton, loaded, className, }) {
    const [state, setState] = useState("skeleton");
    return (_jsxs("div", { className: "flex min-w-0 max-w-full flex-col items-start gap-3", children: [_jsx(Button, { size: "sm", variant: "secondary", "aria-pressed": state === "loaded", "data-testid": `${id}-swap`, onClick: () => setState((current) => current === "skeleton" ? "loaded" : "skeleton"), children: state === "skeleton" ? "Show loaded" : "Show skeleton" }), _jsx("div", { "data-testid": `${id}-slot`, "data-state": state, className: cx("min-w-0", className ?? "w-full"), children: state === "skeleton" ? skeleton : loaded })] }));
}
/** A captioned example inside a specimen. */
export function Example({ label, children, className, }) {
    return (_jsxs("figure", { className: cx("gallery-example", className), children: [_jsx("div", { className: "gallery-example-stage", children: children }), label ? (_jsx("figcaption", { className: "gallery-example-label", children: label })) : null] }));
}
/** Variant × state matrix. Rows are variants, columns are states. */
export function Matrix({ columns, rows, }) {
    const scope = useContext(DemoScope);
    return (_jsxs("div", { className: "gallery-matrix", tabIndex: 0, role: "region", "aria-label": scope ? `${scope}: Comparison` : "Comparison", style: {
            gridTemplateColumns: `var(--gallery-matrix-label) repeat(${columns.length}, max-content)`,
        }, children: [_jsx("span", {}), columns.map((column) => (_jsx("span", { className: "gallery-matrix-head", children: column }, column))), rows.map((row) => (_jsx(MatrixRow, { label: row.label, cells: row.cells }, row.label)))] }));
}
function MatrixRow({ label, cells }) {
    return (_jsxs(_Fragment, { children: [_jsx("span", { className: "gallery-matrix-label", children: label }), cells.map((cell, index) => (_jsx("span", { className: "gallery-matrix-cell", children: cell }, index)))] }));
}
/** Do / Don't guidance. Keep each rule to one sentence. */
export function Rules({ do: dos, dont }) {
    return (_jsxs("div", { className: "gallery-rules", "data-wide": "", children: [_jsxs("div", { className: "gallery-rules-col", "data-tone": "do", children: [_jsx("h3", { className: "type-overline", children: "Do" }), _jsx("ul", { children: dos.map((rule) => (_jsx("li", { children: rule }, rule))) })] }), _jsxs("div", { className: "gallery-rules-col", "data-tone": "dont", children: [_jsx("h3", { className: "type-overline", children: "Don\u2019t" }), _jsx("ul", { children: dont.map((rule) => (_jsx("li", { children: rule }, rule))) })] })] }));
}
/** Lists custom properties with their live computed values in the current theme. */
export function TokenTable({ tokens, title = "Tokens", }) {
    const [values, setValues] = useState({});
    useEffect(() => {
        const read = () => {
            const style = getComputedStyle(document.documentElement);
            setValues(Object.fromEntries(tokens.map(([name]) => [name, style.getPropertyValue(name).trim()])));
        };
        read();
        const observer = new MutationObserver(read);
        observer.observe(document.documentElement, {
            attributes: true,
            attributeFilter: [
                "data-mode",
                "data-palette",
                "data-density",
                "data-glass",
                "style",
            ],
        });
        return () => observer.disconnect();
    }, [tokens]);
    return (_jsxs("section", { className: "gallery-specimen", "aria-label": title, "data-wide": "", children: [_jsx("header", { className: "gallery-specimen-header", children: _jsx("h2", { className: "gallery-specimen-title", children: title }) }), _jsx("div", { className: "gallery-token-scroll", tabIndex: 0, role: "region", "aria-label": `${title} tokens`, children: _jsxs("table", { className: "gallery-token-table", children: [_jsx("thead", { children: _jsxs("tr", { children: [_jsx("th", { children: "Token" }), _jsx("th", { children: "Value now" }), _jsx("th", { children: "Role" })] }) }), _jsx("tbody", { children: tokens.map(([name, note]) => (_jsxs("tr", { children: [_jsx("td", { children: _jsx("code", { dir: "ltr", children: name }) }), _jsx("td", { children: _jsx("code", { dir: "ltr", className: "gallery-token-value", children: values[name] || "—" }) }), _jsx("td", { children: note })] }, name))) })] }) })] }));
}
/** R7.5: the five boxes every component must survive. */
export const CONTAINER_PRESETS = [
    { id: "row", label: "Row 600×40", width: 600, height: 40 },
    { id: "header", label: "Header 360×56", width: 360, height: 56 },
    { id: "tile", label: "Tile 280×180", width: 280, height: 180 },
    { id: "pane", label: "Pane 720×480", width: 720, height: 480 },
    { id: "tall", label: "Tall narrow 240×640", width: 240, height: 640 },
];
/**
 * Render a component inside each preset box (size containers, so the component's
 * container queries respond on both axes) plus a free frame you can drag to resize.
 * e2e/containers.spec.ts scans every [data-lab-frame] for clipped text.
 */
export function ContainerLab(props) {
    const hidden = useContext(HiddenSpecimens);
    const { specimenKey, ...rest } = props;
    return specimenKey && hidden.has(specimenKey) ? null : _jsx(ContainerLabPanel, { ...rest, specimenKey: specimenKey });
}
function ContainerLabPanel({ title = "Container lab", description = "The same component in a table row, a header, a grid tile, a pane and a tall narrow column. Drag the last frame's corner to resize freely.", presets = CONTAINER_PRESETS, children, specimenKey, }) {
    const scope = useContext(DemoScope);
    const label = scope ? `${scope}: ${title}` : title;
    const render = (preset) => typeof children === "function" ? children(preset) : children;
    return (_jsx(Specimen, { specimenKey: specimenKey, title: title, description: description, layout: "bare", wide: true, children: _jsxs("div", { className: "gallery-lab", tabIndex: 0, role: "region", "aria-label": `${label} frames`, children: [[...presets]
                    .sort((a, b) => a.width * a.height - b.width * b.height)
                    .map((preset) => (_jsxs("figure", { className: "gallery-lab-cell", "data-preset-area": preset.width * preset.height, children: [_jsx("div", { className: "gallery-lab-frame", "data-lab-frame": preset.id, style: { width: preset.width, height: preset.height }, children: _jsx(DemoScope, { value: `${label}: ${preset.label}`, children: render(preset) }) }), _jsx("figcaption", { className: "gallery-example-label", children: preset.label })] }, preset.id))), _jsxs("figure", { className: "gallery-lab-cell", children: [_jsx("div", { className: "gallery-lab-frame", "data-lab-frame": "free", "data-resizable": "", style: { width: 420, height: 220 }, children: _jsx(DemoScope, { value: `${label}: Free frame`, children: render(null) }) }), _jsx("figcaption", { className: "gallery-example-label", children: "Free \u2014 drag the corner" })] })] }) }));
}
/** The boxes that put a container-aware component in each tier (R7.2): Metric's and the charts'. */
const TIER_BOXES = {
    micro: {
        label: "micro · 360×48",
        className: "h-12 w-90 rounded-control px-3",
    },
    compact: {
        label: "compact · 280×180",
        className: "h-45 w-70 rounded-tile p-tile",
    },
    full: {
        label: "full · 640×360",
        className: "h-90 w-160 rounded-tile p-tile",
    },
    wide: {
        label: "full · 960×400",
        className: "h-100 w-240 rounded-tile p-tile",
    },
    tall: {
        label: "compact · 240×420",
        className: "h-105 w-60 rounded-tile p-tile",
    },
};
/** The glass-control box of a tier, for SwapSlot and other custom stages. */
export function tierBoxClass(size) {
    return cx("glass-control gallery-tier-box", TIER_BOXES[size].className);
}
/** A component in a box of one tier's size, captioned. It narrows on a phone rather than overhang. */
export function TierBox({ size, label, children, testId, className, }) {
    return (_jsx(Example, { label: label ?? TIER_BOXES[size].label, className: "gallery-tier", children: _jsx("div", { className: cx(tierBoxClass(size), className), "data-testid": testId, children: children }) }));
}
/** One component at micro, compact and full, stacked from smallest to largest. Test ids are `${testId}-${tier}`. */
export function TierRow({ children, testId, }) {
    return (_jsx("div", { className: "gallery-tiers", children: ["micro", "compact", "full"].map((size) => (_jsx(TierBox, { size: size, testId: testId ? `${testId}-${size}` : undefined, children: children(size) }, size))) }));
}
