import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { Surface } from "glass-ux/surface";
/** A canvas catalogue with theme-sized cards; group headings never introduce another glass layer. */
export function CatalogueIndex({ entries, groups, LinkComponent = CatalogueLink, }) {
    return (_jsx("div", { className: "gallery-catalogue", children: groups.map((group) => {
            const items = entries.filter((entry) => entry.group === group);
            if (!items.length)
                return null;
            return (_jsxs("section", { className: "gallery-catalogue-group", "aria-label": group, children: [_jsx("h2", { className: "type-headline", children: group }), _jsx("div", { className: "gallery-catalogue-grid", children: items.map((entry) => (_jsxs(Surface, { as: LinkComponent, entry: entry, material: "card", radius: "tile", padding: "tile", className: "gallery-catalogue-card fa-pressable", children: [_jsxs("span", { className: "gallery-catalogue-card-title type-subtitle", children: [entry.title, entry.trailing] }), _jsx("span", { className: "type-caption text-fg-muted", children: entry.summary })] }, entry.id))) })] }, group));
        }) }));
}
function CatalogueLink({ entry, ...props }) {
    return _jsx("a", { ...props, href: entry.href });
}
