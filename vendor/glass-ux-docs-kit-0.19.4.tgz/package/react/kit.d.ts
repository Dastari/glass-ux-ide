/**
 * Building blocks for gallery sections. Every section uses these so the gallery itself
 * follows one layout: a page header, then specimens (a labelled glass panel holding live
 * examples), then the rules and the tokens the component reads.
 */
import { type ReactNode } from "react";
/** The page wrapper every gallery section renders its header and specimens inside. */
export declare function SectionPage({ children }: {
    children: ReactNode;
}): import("react").JSX.Element;
export interface SpecimenProps {
    title: string;
    /** Set by the demo generator: an earlier demo in the same document may hide this one. */
    specimenKey?: string;
    description?: ReactNode;
    children: ReactNode;
    /** Lay examples out as a wrapping row (default) or a vertical stack. */
    layout?: "row" | "stack" | "grid" | "bare";
    /** Paint a busy image behind the examples to prove the glass reads over content. */
    backdrop?: boolean;
    /** Span the full page width on wide screens (matrices, tables, compositions). */
    wide?: boolean;
    className?: string;
}
/** A titled gallery panel of live examples, labelled with the demo scope when one is set; `layout` arranges the examples and `backdrop` paints busy content behind them. */
export declare function Specimen(props: SpecimenProps): import("react").JSX.Element | null;
/**
 * A specimen with no glass: content sits straight on the ambient canvas, the way L2 tabs,
 * the breadcrumb and entity headers sit in the product (R4.6).
 */
export declare function OnCanvas({ title, description, children, className, specimenKey, }: {
    title: string;
    description?: ReactNode;
    children: ReactNode;
    className?: string;
    /** Set by the demo generator: an earlier demo in the same document may hide this one. */
    specimenKey?: string;
}): import("react").JSX.Element | null;
/**
 * One slot that swaps a skeleton for its content in place, so a test can measure both in the
 * same box (R9.3). Starts on the skeleton.
 */
export declare function SwapSlot({ id, skeleton, loaded, className, }: {
    id: string;
    skeleton: ReactNode;
    loaded: ReactNode;
    className?: string;
}): import("react").JSX.Element;
/** A captioned example inside a specimen. */
export declare function Example({ label, children, className, }: {
    label?: string;
    children: ReactNode;
    className?: string;
}): import("react").JSX.Element;
/** Variant × state matrix. Rows are variants, columns are states. */
export declare function Matrix({ columns, rows, }: {
    /** Typed column definitions, including rendering, sorting, priorities and filters. */
    columns: string[];
    /** Records or matrix rows in display order. */
    rows: Array<{
        label: string;
        cells: ReactNode[];
    }>;
}): import("react").JSX.Element;
/** Do / Don't guidance. Keep each rule to one sentence. */
export declare function Rules({ do: dos, dont }: {
    do: string[];
    dont: string[];
}): import("react").JSX.Element;
/** Lists custom properties with their live computed values in the current theme. */
export declare function TokenTable({ tokens, title, }: {
    tokens: Array<[name: string, note?: string]>;
    title?: string;
}): import("react").JSX.Element;
export interface ContainerPreset {
    id: "row" | "header" | "tile" | "pane" | "tall";
    label: string;
    /** Available width or named width tier. */
    width: number;
    /** Available height used for the component’s size tier. */
    height: number;
}
/** R7.5: the five boxes every component must survive. */
export declare const CONTAINER_PRESETS: ContainerPreset[];
/**
 * Render a component inside each preset box (size containers, so the component's
 * container queries respond on both axes) plus a free frame you can drag to resize.
 * e2e/containers.spec.ts scans every [data-lab-frame] for clipped text.
 */
export declare function ContainerLab(props: Parameters<typeof ContainerLabPanel>[0] & {
    specimenKey?: string;
}): import("react").JSX.Element | null;
declare function ContainerLabPanel({ title, description, presets, children, specimenKey, }: {
    specimenKey?: string;
    title?: string;
    description?: string;
    presets?: ContainerPreset[];
    children: ReactNode | ((preset: ContainerPreset | null) => ReactNode);
}): import("react").JSX.Element;
export type TierBoxSize = "micro" | "compact" | "full" | "wide" | "tall";
/** The glass-control box of a tier, for SwapSlot and other custom stages. */
export declare function tierBoxClass(size: TierBoxSize): string;
/** A component in a box of one tier's size, captioned. It narrows on a phone rather than overhang. */
export declare function TierBox({ size, label, children, testId, className, }: {
    size: TierBoxSize;
    label?: string;
    children: ReactNode;
    testId?: string;
    className?: string;
}): import("react").JSX.Element;
/** One component at micro, compact and full, stacked from smallest to largest. Test ids are `${testId}-${tier}`. */
export declare function TierRow({ children, testId, }: {
    children: (size: TierBoxSize) => ReactNode;
    testId?: string;
}): import("react").JSX.Element;
export {};
