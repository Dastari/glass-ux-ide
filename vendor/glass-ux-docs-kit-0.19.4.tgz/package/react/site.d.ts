import { type ComponentType, type LazyExoticComponent, type ReactNode } from "react";
import { type FamilyConfig, type FamilyEntry } from "./families.js";
import type { SectionGroup, SectionMeta } from "./types.js";
/** One catalogue entry in `site.generated.ts`. */
export interface SiteComponent extends FamilyEntry {
    entry: string;
    description: string;
    section: string;
}
/** A family documented on one page, such as a set of icons. */
export interface SiteCollection extends SiteComponent {
    /** The export named in the page's import line. */
    sample: string;
}
type SiteModule = {
    default: ComponentType;
};
/** Each export's focused demo and the specimens it shows. */
export type SiteCoverage = ReadonlyArray<{
    id: string;
    specimens?: Array<{
        key: string;
        title: string;
    }>;
}>;
/** What component pages load on demand, from `site-content.generated.ts`. */
export interface SiteContent {
    /** The specimens each export's focused demo shows, from the demo generator. */
    loadCoverage: () => Promise<SiteCoverage>;
    /** Each focused demo's module, by path. */
    demoLoaders: Record<string, () => Promise<SiteModule>>;
    /** Fetches one export's API reference. */
    loadApi: (id: string) => Promise<unknown>;
    /** Fetches one export's complete usage source. */
    loadExample: (id: string) => Promise<string>;
}
/** What `glass-ux-docs api` writes to `site.generated.ts`: the project's catalogue and its loaders. */
export interface DocsSite {
    /** Display name. */
    title: string;
    /** The package the pages document. */
    packageName: string;
    /** Version the pages and links describe. */
    version: string;
    /** Repository home page, when `package.json` names one. */
    repositoryUrl: string | null;
    /** Where relative links in guides resolve; without one they stay as written. */
    docsSourceUrl: string | null;
    /** Generated catalogue. */
    catalogue: readonly SiteComponent[];
    /** Which exports share a document. */
    families: FamilyConfig;
    /** Guides in navigation order. */
    guides: readonly {
        id: string;
        title: string;
    }[];
    /** Families documented on one page. */
    collections: readonly SiteCollection[];
    /** Family id to the badge on its pages. */
    badges: Readonly<Record<string, string>>;
    /** Each section's metadata, by module path. */
    sectionMetas: Record<string, unknown>;
    /** Each section's module, by path. */
    sectionLoaders: Record<string, () => Promise<SiteModule>>;
    /** Loads what component pages need, apart from navigation. */
    loadContent: () => Promise<SiteContent>;
    /** Fetches one guide's Markdown. */
    loadGuide: (id: string) => Promise<string>;
}
/** A section with its lazily loaded component. */
export interface SiteSection extends SectionMeta {
    Component: LazyExoticComponent<ComponentType>;
}
/** Gallery navigation groups in display order; sections sort by group, then by their `order`. */
export declare const GROUPS: SectionGroup[];
/** One site's sections, families and cached loaders, shared by its pages. */
export declare function siteRuntime(site: DocsSite): {
    sections: {
        Component: LazyExoticComponent<ComponentType>;
        id: string;
        title: string;
        group: SectionGroup;
        order: number;
        summary: string;
        badge?: string;
    }[];
    findSection: (id: string) => SiteSection | undefined;
    families: {
        all: (SiteComponent & {
            components: SiteComponent[];
        })[];
        find: (id: string) => (SiteComponent & {
            components: SiteComponent[];
        }) | undefined;
        destination: (id: string) => {
            id: string;
            hash?: string;
        };
    };
    /** Component page content: a stable promise, so a page can suspend on it with `use`. */
    content: () => Promise<{
        specimens: Map<string, {
            key: string;
            title: string;
        }[]>;
        loadDemo: (id: string) => Promise<SiteModule> | undefined;
        focusedDemos: Map<string, LazyExoticComponent<ComponentType>>;
        loadApi: (id: string) => Promise<unknown>;
        loadExample: (id: string) => Promise<string>;
    }>;
};
/** Gives the documentation pages their project's generated `site`. Wrap the routes in it once. */
export declare function DocsKitProvider({ site, children }: {
    site: DocsSite;
    children: ReactNode;
}): import("react").JSX.Element;
/** The `site` from the nearest {@link DocsKitProvider}. */
export declare function useDocsSite(): DocsSite;
export {};
