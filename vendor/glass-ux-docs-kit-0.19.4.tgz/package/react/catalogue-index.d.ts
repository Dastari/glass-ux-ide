import type { ComponentProps, ComponentType, ReactNode } from "react";
/** A documentation destination; the host owns its route and optional status indicator. */
export interface CatalogueEntry {
    /** Stable catalogue key, also available to the host route adapter. */
    id: string;
    /** Human-readable component or section name. */
    title: string;
    /** Short purpose shown beneath the name. */
    summary: string;
    /** Heading in groups under which this destination is listed. */
    group: string;
    /** Destination used by the default anchor renderer. */
    href: string;
    /** Optional status or metadata beside the title. */
    trailing?: ReactNode;
}
/** Forward anchor props to the host router's Link, using entry to choose the destination. */
export type CatalogueLinkProps = Omit<ComponentProps<"a">, "href"> & {
    entry: CatalogueEntry;
};
/** A canvas catalogue with theme-sized cards; group headings never introduce another glass layer. */
export declare function CatalogueIndex({ entries, groups, LinkComponent, }: {
    /** Destinations rendered in their supplied order within each group. */
    entries: CatalogueEntry[];
    /** Action groups in display order. */
    groups: readonly string[];
    /** Host router adapter; forward the supplied anchor props and use entry for the route. */
    LinkComponent?: ComponentType<CatalogueLinkProps>;
}): import("react").JSX.Element;
