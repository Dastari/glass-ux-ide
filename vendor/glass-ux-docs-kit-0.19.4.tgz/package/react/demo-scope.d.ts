export declare const DemoScope: import("react").Context<string | undefined>;
export declare const HiddenSpecimens: import("react").Context<ReadonlySet<string>>;
/** The element id of a generated specimen, so a later section can link to it. */
export declare const specimenAnchor: (key: string) => string;
