"use client";
import { jsx as _jsx } from "react/jsx-runtime";
import { useEffect, useState } from "react";
import { Markdown } from "glass-ux/ai/markdown";
import { Notice } from "glass-ux/notice";
import { Skeleton } from "glass-ux/skeleton";
import { useDocsSite } from "./site.js";
/** A version-matched human guide from the installed release. */
export function LibraryGuide({ id }) {
    const site = useDocsSite();
    const [text, setText] = useState("");
    const [error, setError] = useState("");
    useEffect(() => {
        let active = true;
        setText("");
        setError("");
        site
            .loadGuide(id)
            .then((value) => {
            const base = site.docsSourceUrl;
            if (active)
                setText(base
                    ? value.replace(/\]\((?!https?:|#)([^)]+)\)/g, (_match, path) => `](${new URL(path, base).href})`)
                    : value);
        })
            .catch((reason) => {
            if (active)
                setError(String(reason));
        });
        return () => {
            active = false;
        };
    }, [site, id]);
    return (_jsx("article", { className: "gallery-documentation gallery-guide-document", children: error ? (_jsx(Notice, { tone: "danger", children: error })) : text ? (_jsx(Markdown, { wrapTableCells: true, anchors: true, text: text })) : (_jsx(Skeleton.Text, { lines: 4 })) }));
}
