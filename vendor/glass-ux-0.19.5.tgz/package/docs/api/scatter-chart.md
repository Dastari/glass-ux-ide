# ScatterChart

Two measures per item — CPU against memory for every endpoint. 8px dots ringed in the
surface colour so overlaps stay legible; the pointer only has to be nearest, not on the dot.

  micro    the dots alone
  compact  the dots over a baseline, passive legend
  full     both axes with their names, the interactive legend, nearest-dot tooltip, and the
           arrow keys stepping through dots left to right

`import { ScatterChart } from "glass-ux/charts"`

[Live examples](https://dastari.github.io/glass-ux/components/scatter-chart)

## Props

| Prop | Type | Valid options | Required | Default | Description |
| --- | --- | --- | --- | --- | --- |
| bands | `readonly ReferenceBand[] \| undefined` | See type | no | — | Shaded y ranges (a healthy range). Without them, status thresholds shade up to the next one. |
| emptyText | `ReactNode` | See type | no | — | One factual line for the empty state (R2.5): "No samples in the last hour". |
| errorText | `ReactNode` | See type | no | — | What failed and what to do (R2.4): "Agent offline — retry when NST-C106 reconnects". |
| label | `string` | See type | yes | — | Accessible name: what is plotted, for what, over when ("CPU · NST-C106 · last hour"). |
| locale | `string \| undefined` | See type | no | — | BCP 47 locale for this chart's numbers, dates and table. Default: the nearest `LocaleProvider`, then `configureLocale()`, then `<html lang>`, then en-US. |
| onRetry | `(() => void) \| undefined` | See type | no | — | Called with no arguments when the person presses Retry in the error state. The button appears only when this is set, `state` is "error" and the tier is not micro. |
| series | `readonly ScatterSeries[]` | See type | yes | — | Three series at most: any two dots can sit side by side, so every pair must differ. |
| state | `ChartState \| undefined` | "error", "loading", "ready", "empty" | no | "ready" | Controlled view state, including loading, empty and error states. |
| thresholds | `readonly Threshold[] \| undefined` | See type | no | — | Lines across the plot at y values (a limit, a target), labelled at the line's end, in the y axis's format. |
| title | `string \| undefined` | See type | no | — | A visible label in Metric's label role. Omit inside a panel whose header already names it. |
| x | `ValueAxis` | See type | yes | — | Horizontal coordinate or accessor. |
| y | `ValueAxis` | See type | yes | — | Vertical coordinate or accessor. |

Inherited properties:

| Prop | Type | Valid options | Required | Default | Description |
| --- | --- | --- | --- | --- | --- |
| className | `string \| undefined` | See type | no | — | Classes applied to the outer element for layout. Use the component props and theme tokens for its appearance. |
| defaultValue | `string \| number \| readonly string[] \| undefined` | See type | no | — | The initial value when using the component without controlling its state. |
| ref | `Ref<HTMLElement> \| undefined` | See type | no | — | Allows getting a ref to the component instance. Once the component unmounts, React will set `ref.current` to `null` (or call the ref with `null` if you passed a callback ref). |

Also accepts the element’s standard HTML attributes and React DOM events.
