# ResultDiff

A change preview — config, registry or policy — as a unified diff in a result card. The
target is a context chip; the counts are the data line. The diff itself is `DiffView`.

`import { ResultDiff } from "glass-ux/ai"`

[Live examples](https://dastari.github.io/glass-ux/components/result-diff)

## Props

| Prop | Type | Valid options | Required | Default | Description |
| --- | --- | --- | --- | --- | --- |
| result | `ResultBase & { type: "diff"; target?: import("../types.js").EntityRef; language?: string; lines: import("../types.js").DiffLine[]; }` | See type | yes | — | The diff result: `lines` in order (added, removed or context), an optional `target` entity shown as a chip, and the title used in the accessible name. |
