# AiSurfaceProvider

Choose the surrounding canvas, panel or floating surface so assistant cards use the appropriate material.

`import { AiSurfaceProvider } from "glass-ux/ai"`

[Live examples](https://dastari.github.io/glass-ux/components/ai-surface-provider)

## Props

| Prop | Type | Valid options | Required | Default | Description |
| --- | --- | --- | --- | --- | --- |
| children | `ReactNode` | See type | yes | — | The content or component slots rendered inside the component. |
| surface | `AiSurface` | "canvas", "float", "panel" | yes | — | Where the cards below are drawn: `canvas` (glass-panel), `panel` (glass-control) or `float` (glass-overlay). |
