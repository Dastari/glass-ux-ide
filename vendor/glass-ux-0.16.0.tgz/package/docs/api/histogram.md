# Histogram

How values spread — check-in latency across the fleet. Pass raw `values` to bin here, or
precomputed `bins` when the host has already counted them. Columns touch (the 2px surface
gap between them), the axis labels the bin edges, and the tooltip names the bin's range and
count. Tiers are the column chart's.

`import { Histogram } from "glass-ux/charts"`

[Live examples](https://dastari.github.io/glass-ux/components/histogram)

## Props

| Prop | Type | Valid options | Required | Default | Description |
| --- | --- | --- | --- | --- | --- |
| bins | `number \| readonly HistogramBin[] \| undefined` | See type | no | — | About how many bins (d3 picks nice edges near this). The bins, touching and of equal width: each column is drawn the same width, and the axis labels their edges. |
| countLabel | `string \| undefined` | See type | no | — | What is counted: "Endpoints", "Check-ins". |
| domain | `Domain \| undefined` | See type | no | — | The x range to bin over; defaults to the data's extent. |
| emptyText | `ReactNode` | See type | no | — | One factual line for the empty state (R2.5): "No samples in the last hour". |
| errorText | `ReactNode` | See type | no | — | What failed and what to do (R2.4): "Agent offline — retry when NST-C106 reconnects". |
| format | `((value: number, locale: string) => string) \| undefined` | See type | no | — | Full control of the number (the unit is still appended). Receives the chart's resolved locale as its second argument. |
| label | `string` | See type | yes | — | Accessible name: what is plotted, for what, over when ("CPU · NST-C106 · last hour"). |
| locale | `string \| undefined` | See type | no | — | BCP 47 locale for this chart's numbers, dates and table. Default: the nearest `LocaleProvider`, then `configureLocale()`, then `<html lang>`, then en-US. |
| onRetry | `(() => void) \| undefined` | See type | no | — | Called with no arguments when the person presses Retry in the error state. The button appears only when this is set, `state` is "error" and the tier is not micro. |
| state | `ChartState \| undefined` | "error", "loading", "ready", "empty" | no | — | Controlled view state, including loading, empty and error states. |
| title | `string \| undefined` | See type | no | — | A visible label in Metric's label role. Omit inside a panel whose header already names it. |
| unit | `ChartUnit \| undefined` | See type | no | — | "%", "GB", "ms", or a counted noun ({ one, other })… "%" sticks to the number; other units take a space. |
| values | `readonly number[] \| undefined` | See type | no | — | The raw values; they are binned here. |

Inherited properties:

| Prop | Type | Valid options | Required | Default | Description |
| --- | --- | --- | --- | --- | --- |
| className | `string \| undefined` | See type | no | — | Classes applied to the outer element for layout. Use the component props and theme tokens for its appearance. |
| defaultValue | `string \| number \| readonly string[] \| undefined` | See type | no | — | The initial value when using the component without controlling its state. |
| ref | `Ref<HTMLElement> \| undefined` | See type | no | — | Allows getting a ref to the component instance. Once the component unmounts, React will set `ref.current` to `null` (or call the ref with `null` if you passed a callback ref). |

Also accepts the element’s standard HTML attributes and React DOM events.
